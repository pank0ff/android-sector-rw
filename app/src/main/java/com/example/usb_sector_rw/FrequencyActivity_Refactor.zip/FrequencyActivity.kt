package com.example.yourapp

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FrequencyActivity : AppCompatActivity() {

    private lateinit var measureHandler: Handler
    private lateinit var measureRunnable: Runnable
    private var isMeasuring = false
    private lateinit var logText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frequency)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        logText = findViewById(R.id.logText)

        val btnMeasureTest = findViewById<Button>(R.id.btnMeasureTest)
        val btnMeasureExec = findViewById<Button>(R.id.btnMeasureExec)
        val btnMeasureExecStop = findViewById<Button>(R.id.btnMeasureExecStop)
        val btnEchoTest = findViewById<Button>(R.id.btnEchoTest)
        val btnStopMeasure = findViewById<Button>(R.id.btnStopMeasure)

        btnMeasureTest.setOnClickListener {
            // TODO: перенеси сюда соответствующий код из MainActivity
        }

        btnMeasureExec.setOnClickListener {
            // TODO: перенеси сюда соответствующий код из MainActivity
        }

        btnMeasureExecStop.setOnClickListener {
            // TODO: перенеси сюда соответствующий код из MainActivity
        }

        btnEchoTest.setOnClickListener {
            // TODO: перенеси сюда соответствующий код из MainActivity
        }

        btnStopMeasure.setOnClickListener {
            // TODO: перенеси сюда соответствующий код из MainActivity
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}